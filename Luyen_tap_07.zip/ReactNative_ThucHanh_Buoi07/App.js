import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
} from 'react-native';

const App = () => {
  // ===== BÀI 1: CONTROLLED COMPONENT =====
  const [name, setName] = useState('');

  // ===== BÀI 3: FORM ĐĂNG KÝ =====
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const [errors, setErrors] = useState({});
  const [success, setSuccess] = useState(false);

  const validate = () => {
    const newErrors = {};

    if (!fullName.trim()) {
      newErrors.fullName = 'Họ tên không được để trống';
    }

    if (!email.trim()) {
      newErrors.email = 'Email không được để trống';
    } else if (!/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(email)) {
      newErrors.email = 'Email không đúng định dạng';
    }

    if (!password) {
      newErrors.password = 'Mật khẩu không được để trống';
    } else if (password.length < 6) {
      newErrors.password = 'Mật khẩu phải có ít nhất 6 ký tự';
    }

    if (!confirmPassword) {
      newErrors.confirmPassword = 'Vui lòng nhập lại mật khẩu';
    } else if (confirmPassword !== password) {
      newErrors.confirmPassword = 'Mật khẩu xác nhận không khớp';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    setSuccess(false);

    if (validate()) {
      setSuccess(true);
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.mainTitle}>BUỔI 07 - THỰC HÀNH REACT NATIVE</Text>

      {/* ================= BÀI 1 ================= */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Bài 1 - Controlled Component</Text>

        <Text style={styles.label}>Nhập họ tên:</Text>

        <TextInput
          style={styles.input}
          placeholder="Nhập họ tên của bạn"
          value={name}
          onChangeText={setName}
        />

        <Text style={styles.result}>
          Bạn đã nhập: {name}
        </Text>
      </View>

      {/* ================= BÀI 2 ================= */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Bài 2 - Component lồng Component</Text>

        <UserProfile
          name="Nguyễn Văn A"
          bio="Lập trình viên React Native"
          profileImage="https://i.pravatar.cc/150?img=1"
        />

        <UserProfile
          name="Trần Thị B"
          bio="Nhà thiết kế UI/UX"
          profileImage="https://i.pravatar.cc/150?img=2"
        />
      </View>

      {/* ================= BÀI 3 ================= */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Bài 3 - Form đăng ký</Text>

        <TextInput
          style={styles.input}
          placeholder="Họ tên"
          value={fullName}
          onChangeText={setFullName}
        />
        {errors.fullName && (
          <Text style={styles.error}>{errors.fullName}</Text>
        )}

        <TextInput
          style={styles.input}
          placeholder="Email"
          keyboardType="email-address"
          autoCapitalize="none"
          value={email}
          onChangeText={setEmail}
        />
        {errors.email && (
          <Text style={styles.error}>{errors.email}</Text>
        )}

        <TextInput
          style={styles.input}
          placeholder="Mật khẩu"
          secureTextEntry
          value={password}
          onChangeText={setPassword}
        />
        {errors.password && (
          <Text style={styles.error}>{errors.password}</Text>
        )}

        <TextInput
          style={styles.input}
          placeholder="Confirm mật khẩu"
          secureTextEntry
          value={confirmPassword}
          onChangeText={setConfirmPassword}
        />
        {errors.confirmPassword && (
          <Text style={styles.error}>{errors.confirmPassword}</Text>
        )}

        <TouchableOpacity style={styles.button} onPress={handleSubmit}>
          <Text style={styles.buttonText}>SUBMIT</Text>
        </TouchableOpacity>

        {success && (
          <Text style={styles.success}>Đăng ký thành công</Text>
        )}
      </View>
    </ScrollView>
  );
};

// ================= COMPONENT AVATAR =================
const Avatar = ({ imageUrl }) => {
  return (
    <View style={styles.avatarContainer}>
      <Text style={styles.avatarText}>ẢNH</Text>
      <Text style={styles.avatarUrl} numberOfLines={1}>
        {imageUrl}
      </Text>
    </View>
  );
};

// ================= COMPONENT USER PROFILE =================
const UserProfile = ({ name, bio, profileImage }) => {
  return (
    <View style={styles.profile}>
      <Avatar imageUrl={profileImage} />

      <View style={styles.profileInfo}>
        <Text style={styles.profileName}>{name}</Text>
        <Text style={styles.profileBio}>{bio}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    paddingTop: 50,
    paddingBottom: 40,
  },

  mainTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 25,
  },

  section: {
    marginBottom: 25,
    padding: 16,
    borderWidth: 1,
    borderColor: '#cccccc',
    borderRadius: 10,
  },

  sectionTitle: {
    fontSize: 19,
    fontWeight: 'bold',
    marginBottom: 15,
  },

  label: {
    fontSize: 16,
    marginBottom: 8,
  },

  input: {
    height: 48,
    borderWidth: 1,
    borderColor: '#999999',
    borderRadius: 6,
    paddingHorizontal: 12,
    marginTop: 10,
  },

  result: {
    fontSize: 16,
    marginTop: 15,
  },

  profile: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#dddddd',
  },

  avatarContainer: {
    width: 75,
    height: 75,
    borderRadius: 38,
    borderWidth: 1,
    borderColor: '#888888',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 15,
    overflow: 'hidden',
  },

  avatarText: {
    fontWeight: 'bold',
  },

  avatarUrl: {
    fontSize: 7,
    textAlign: 'center',
    paddingHorizontal: 3,
  },

  profileInfo: {
    flex: 1,
  },

  profileName: {
    fontSize: 18,
    fontWeight: 'bold',
  },

  profileBio: {
    fontSize: 14,
    marginTop: 5,
  },

  error: {
    marginTop: 5,
    fontSize: 14,
  },

  button: {
    height: 48,
    marginTop: 20,
    borderRadius: 6,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#555555',
  },

  buttonText: {
    fontSize: 17,
    fontWeight: 'bold',
  },

  success: {
    marginTop: 20,
    textAlign: 'center',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default App;
