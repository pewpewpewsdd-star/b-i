# Buổi 07 - Thực hành React Native

Project gồm 3 bài:

## Bài 1 - Controlled Component
- Functional Component
- `useState`
- `TextInput`
- `value`
- `onChangeText`
- Hiển thị lại họ tên người dùng nhập.

## Bài 2 - Component lồng Component
- `Avatar`
- `UserProfile`
- Truyền dữ liệu bằng `props`
- Hiển thị 2 hồ sơ người dùng.

## Bài 3 - Form đăng ký
Gồm:
- Họ tên
- Email
- Mật khẩu
- Confirm mật khẩu

Validation:
- Không được để trống
- Email đúng định dạng
- Mật khẩu tối thiểu 6 ký tự
- Confirm mật khẩu phải khớp

Khi dữ liệu hợp lệ, hiển thị:
`Đăng ký thành công`

## Cách chạy

```bash
npm install
npx expo start
```

Sau đó:
- Nhấn `a` để chạy Android Emulator.
- Hoặc quét QR bằng Expo Go.

## Lưu ý

Trong Bài 2, phần Avatar được thiết kế bằng View/Text để project vẫn chạy ổn định ngay cả khi thiết bị không tải được ảnh từ Internet.
