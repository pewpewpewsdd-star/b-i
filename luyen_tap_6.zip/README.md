# React Native - Component & Hooks Practice

## Nội dung
Project gồm 3 bài thực hành:

1. Greeting: tạo Functional Component và truyền props.
2. StudentInfo: tái sử dụng component và truyền nhiều props.
3. CounterHook: sử dụng useState để cập nhật số lần bấm.

## Cấu trúc
- App.js
- Greeting.js
- StudentInfo.js
- CounterHook.js

## Cách chạy
1. Tạo một project React Native/Expo mới.
2. Chép 4 file `.js` vào thư mục project.
3. Đảm bảo `App.js` là file khởi chạy của project.
4. Chạy project bằng Expo hoặc React Native CLI tùy môi trường học tập.

## Kiến thức sử dụng
- Functional Component
- Props
- useState
- StyleSheet
- View, Text, Button, ScrollView
