import React, { useState } from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

const CounterHook = () => {
  const [count, setCount] = useState(0);

  return (
    <View style={styles.container}>
      <Text style={styles.text}>
        Số lần bấm: {count}
      </Text>

      <Button
        title="Tăng"
        onPress={() => setCount(count + 1)}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    alignItems: 'center',
  },
  text: {
    fontSize: 20,
    marginBottom: 10,
  },
});

export default CounterHook;
