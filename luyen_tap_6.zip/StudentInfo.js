import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const StudentInfo = (props) => {
  return (
    <View style={styles.container}>
      <Text>Họ tên: {props.name}</Text>
      <Text>Lớp: {props.className}</Text>
      <Text>Ngành: {props.major}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 15,
    margin: 10,
    borderWidth: 1,
    borderRadius: 5,
  },
});

export default StudentInfo;
