import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const Greeting = (props) => {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>
        Xin chào, {props.name}!
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 10,
  },
  text: {
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default Greeting;
