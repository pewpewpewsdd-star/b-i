import React from 'react';
import { ScrollView, StyleSheet, Text } from 'react-native';
import Greeting from './Greeting';
import StudentInfo from './StudentInfo';
import CounterHook from './CounterHook';

const App = () => {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Bài thực hành Component & Hooks</Text>

      <Text style={styles.section}>Bài 1 - Greeting</Text>
      <Greeting name="Nguyễn Văn A" />
      <Greeting name="Trần Thị B" />

      <Text style={styles.section}>Bài 2 - StudentInfo</Text>
      <StudentInfo
        name="Nguyễn Văn A"
        className="CNTT01"
        major="Công nghệ thông tin"
      />
      <StudentInfo
        name="Trần Thị B"
        className="CNTT02"
        major="Công nghệ thông tin"
      />
      <StudentInfo
        name="Lê Văn C"
        className="CNTT03"
        major="Công nghệ thông tin"
      />

      <Text style={styles.section}>Bài 3 - CounterHook</Text>
      <CounterHook />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    paddingTop: 60,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  section: {
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 20,
    marginBottom: 10,
  },
});

export default App;
